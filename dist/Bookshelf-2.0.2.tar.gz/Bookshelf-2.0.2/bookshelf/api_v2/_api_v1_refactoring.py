# vim: ai ts=4 sts=4 et sw=4 ft=python fdm=indent et foldlevel=0

import boto.ec2
import json
import os
import pyrax
import re
import socket
import sys
import uuid

from boto.ec2.blockdevicemapping import BlockDeviceMapping, EBSBlockDeviceType
from fabric.api import env, sudo, local, settings, run
from fabric.operations import (get as get_file,
                               put as upload_file)
from fabric.colors import green, yellow, red
from fabric.context_managers import cd, hide, lcd
from fabric.contrib.files import (append as file_append,
                                  contains as file_contains,
                                  comment as comment_line,
                                  exists,
                                  sed,
                                  contains)
from itertools import chain
from sys import exit
from time import sleep




def ssh_session(key_filename,
                username,
                ip_address,
                *cli):
    """ opens a ssh shell to the host """
    local('ssh -t -i %s %s@%s %s' % (key_filename,
                                     username,
                                     ip_address,
                                     "".join(chain.from_iterable(cli))))


