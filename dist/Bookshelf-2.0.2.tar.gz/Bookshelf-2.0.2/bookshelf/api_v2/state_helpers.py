# vim: ai ts=4 sts=4 et sw=4 ft=python fdm=indent et foldlevel=0

import boto.ec2
import json
import os
import pyrax
import re
import socket
import sys
import uuid

from boto.ec2.blockdevicemapping import BlockDeviceMapping, EBSBlockDeviceType
from fabric.api import env, sudo, local, settings, run
from fabric.operations import (get as get_file,
                               put as upload_file)
from fabric.colors import green, yellow, red
from fabric.context_managers import cd, hide, lcd
from fabric.contrib.files import (append as file_append,
                                  contains as file_contains,
                                  comment as comment_line,
                                  exists,
                                  sed,
                                  contains)
from itertools import chain
from sys import exit
from time import sleep




def is_there_state():
    """ checks is there is valid state available on disk """
    if os.path.isfile('data.json'):
        return True
    else:
        return False


def load_state_from_disk():
    """ loads the state from a loca data.json file
    """
    if is_there_state():
        with open('data.json', 'r') as f:
            data = json.load(f)
        return data
    else:
        return False


def save_state_locally(cloud,
                       instance_id,
                       region,
                       username,
                       access_key_id,
                       secret_access_key):
    """ queries EC2 for details about a particular instance_id and
        stores those details locally
    """
    if cloud == 'ec2':
        # retrieve the IP information from the instance
        data = get_ec2_info(instance_id,
                            region,
                            access_key_id,
                            secret_access_key,
                            username)
    if cloud == 'rackspace':
        # retrieve the IP information from the instance
        data = get_rackspace_info(instance_id,
                                  region,
                                  access_key_id,
                                  secret_access_key,
                                  username)
        data['cloud_type'] = 'rackspace'

    # dump it all
    with open('data.json', 'w') as f:
        json.dump(data, f)

