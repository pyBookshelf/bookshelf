# vim: ai ts=4 sts=4 et sw=4 ft=python fdm=indent et foldlevel=0

import boto.ec2
import json
import os
import pyrax
import re
import socket
import sys
import uuid

from boto.ec2.blockdevicemapping import BlockDeviceMapping, EBSBlockDeviceType
from fabric.api import env, sudo, local, settings, run
from fabric.operations import (get as get_file,
                               put as upload_file)
from fabric.colors import green, yellow, red
from fabric.context_managers import cd, hide, lcd
from fabric.contrib.files import (append as file_append,
                                  contains as file_contains,
                                  comment as comment_line,
                                  exists,
                                  sed,
                                  contains)
from itertools import chain
from sys import exit
from time import sleep



def create_image(cloud,
                 region,
                 access_key_id,
                 secret_access_key,
                 instance_id,
                 name,
                 description,
                 block_device_mapping=None):
    """ proxy call for ec2, rackspace create ami backend functions """
    if cloud == 'ec2':
        return(create_ami(region,
                          access_key_id,
                          secret_access_key,
                          instance_id,
                          name,
                          description,
                          block_device_mapping=None))

    if cloud == 'rackspace':
        return(create_rackspace_image(region,
                                      access_key_id,
                                      secret_access_key,
                                      instance_id,
                                      name,
                                      description,
                                      block_device_mapping=None))




def create_server(cloud,
                  region,
                  access_key_id,
                  secret_access_key,
                  distribution,
                  disk_name,
                  disk_size,
                  ami,
                  key_pair,
                  instance_type,
                  username,
                  security_groups='',
                  instance_name='',
                  tags={}):
    """
        Create a new instance
    """
    if cloud == 'ec2':
        create_server_ec2(distribution,
                          region,
                          access_key_id,
                          secret_access_key,
                          disk_name,
                          disk_size,
                          ami,
                          key_pair,
                          instance_type,
                          username,
                          tags,
                          security_groups)
    if cloud == 'rackspace':
        create_server_rackspace(distribution=distribution,
                                region=region,
                                access_key_id=access_key_id,
                                secret_access_key=secret_access_key,
                                disk_name=disk_name,
                                disk_size=disk_size,
                                ami=ami,
                                key_pair=key_pair,
                                instance_type=instance_type,
                                username=username,
                                tags=tags,
                                instance_name=instance_name,
                                security_groups=security_groups)



def destroy(cloud, region, instance_id, access_key_id, secret_access_key):
    if cloud == 'ec2':
        destroy_ec2(region, instance_id, access_key_id, secret_access_key)
    if cloud == 'rackspace':
        destroy_rackspace(region, instance_id, access_key_id, secret_access_key)



def down(cloud, instance_id, region, access_key_id, secret_access_key):
    halt(cloud, instance_id, region, access_key_id, secret_access_key)



def halt(cloud, instance_id, region, access_key_id, secret_access_key):
    if cloud == 'ec2':
        down_ec2(instance_id, region, access_key_id, secret_access_key)
    if cloud == 'rackspace':
        down_rackspace(instance_id, region, access_key_id, secret_access_key)



def is_ssh_available(host, port=22):
    """ checks if ssh port is open """
    s = socket.socket()
    try:
        s.connect((host, port))
        return True
    except:
        return False


def status(cloud,
           region,
           instance_id,
           access_key_id,
           secret_access_key,
           username):

    if cloud == 'ec2':
        print_ec2_info(region,
                       instance_id,
                       access_key_id,
                       secret_access_key,
                       username)

    if cloud == 'rackspace':
        print_rackspace_info(region,
                             instance_id,
                             access_key_id,
                             secret_access_key,
                             username)


def terminate():
    destroy()


def up(cloud, instance_id, region, access_key_id, secret_access_key, username):
    if cloud == 'ec2':
        up_ec2(region, access_key_id, secret_access_key, instance_id, username)
    if cloud == 'rackspace':
        up_rackspace(region,
                     access_key_id,
                     secret_access_key,
                     instance_id,
                     username)


def wait_for_ssh(host, port=22, timeout=600):
    """ probes the ssh port and waits until it is available """
    log_yellow('waiting for ssh...')
    for iteration in xrange(1, timeout): #noqa
        sleep(1)
        if is_ssh_available(host, port):
            return True
        else:
            log_yellow('waiting for ssh...')
