# vim: ai ts=4 sts=4 et sw=4 ft=python fdm=indent et foldlevel=0

import boto.ec2
import json
import os
import pyrax
import re
import socket
import sys
import uuid

from boto.ec2.blockdevicemapping import BlockDeviceMapping, EBSBlockDeviceType
from fabric.api import env, sudo, local, settings, run
from fabric.operations import (get as get_file,
                               put as upload_file)
from fabric.colors import green, yellow, red
from fabric.context_managers import cd, hide, lcd
from fabric.contrib.files import (append as file_append,
                                  contains as file_contains,
                                  comment as comment_line,
                                  exists,
                                  sed,
                                  contains)
from itertools import chain
from sys import exit
from time import sleep



def enable_marathon_basic_authentication(principal, password):
    """ configures marathon to start with authentication """
    upstart_file = '/etc/init/marathon.conf'
    with hide('running', 'stdout'):
        sudo('echo -n "{}" > /etc/marathon-mesos.credentials'.format(password))
    boot_args = ' '.join(['exec',
                          '/usr/bin/marathon',
                          '--http_credentials',
                          '"{}:{}"'.format(principal, password),
                          '--mesos_authentication_principal',
                          principal,
                          '--mesos_authentication_secret_file',
                          '/etc/marathon-mesos.credentials'])

    # check if the init conf file contains the exact user and password
    if not file_contains(upstart_file, boot_args, use_sudo=True):
        sed(upstart_file, 'exec /usr/bin/marathon.*', boot_args, use_sudo=True)
        file_attribs(upstart_file, mode=700, sudo=True)
        restart_service('marathon')


def enable_mesos_basic_authentication(principal, password):
    """ enables and adds a new authorized principal """
    restart = False
    secrets_file = '/etc/mesos/secrets'
    secrets_entry = '%s %s' % (principal, password)
    if not file_contains(secrets_file, secrets_entry, use_sudo=True):
        file_append(secrets_file, secrets_entry, use_sudo=True)
        file_attribs(secrets_file, mode=700, sudo=True)
        restart = True

    # set new startup parameters for mesos-master
    with cd('/etc/mesos-master'):
        if not file_contains('credentials',
                             secrets_file, use_sudo=True):
            sudo('echo %s > credentials' % secrets_file)
            restart = True

        if not exists('?authenticate', use_sudo=True):
            sudo('touch \?authenticate')
            file_attribs('?authenticate', mode=700, sudo=True)
            restart = True

    if restart:
        restart_service('mesos-master')


def install_mesos_single_box_mode(distribution):
    """ install mesos (all of it) on a single node"""

    if 'ubuntu' in distribution:
        log_green('adding mesosphere apt-key')
        apt_add_key(keyid='E56151BF')

        os = lsb_release()
        apt_string = 'deb http://repos.mesosphere.io/%s %s main' % (
            os['DISTRIB_ID'], os['DISTRIB_CODENAME'])

        log_green('adding mesosphere apt repository')
        apt_add_repository_from_apt_string(apt_string, 'mesosphere.list')

        log_green('installing ubuntu development tools')
        install_ubuntu_development_tools()

        install_oracle_java(distribution, '8')

        log_green('installing mesos and marathon')
        apt_install(packages=['mesos', 'marathon'])

        if not file_contains('/etc/default/mesos-master',
                             'MESOS_QUORUM=1', use_sudo=True):
            file_append('/etc/default/mesos-master',
                        'MESOS_QUORUM=1', use_sudo=True)

            log_green('restarting services...')
            for svc in ['zookeeper', 'mesos-master', 'mesos-slave', 'marathon']:
                restart_service(svc)

        if not file_contains('/etc/mesos-slave/work_dir',
                             '/data/mesos', use_sudo=True):
            file_append('/etc/mesos-slave/work_dir',
                        '/data/mesos', use_sudo=True)

            log_green('restarting services...')
            for svc in ['mesos-slave']:
                restart_service(svc)

        log_green('enabling nginx autoindex on /...')
        insert_line_in_file_after_regex(
            path='/etc/nginx/sites-available/default',
            line='                autoindex on;',
            after_regex='^[^#]*location \/ {',
            use_sudo=True)
        log_green('restarting nginx')
        restart_service('nginx')

