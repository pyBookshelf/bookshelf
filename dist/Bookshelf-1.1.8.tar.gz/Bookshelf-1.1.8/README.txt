Bookshelf

A wrapper layer for different fabric operations.
The goal is to encapsulate different frameworks into a single re-usable api for fabric, while keeping it simple and fairly dynamic.


